package cz.pokus.pokus.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class IdResponseDTO {
    private Long playerId;
}
