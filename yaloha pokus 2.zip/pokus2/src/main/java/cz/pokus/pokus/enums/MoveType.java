package cz.pokus.pokus.enums;

public enum MoveType {
    REVEAL,
    MARK
}
