package cz.pokus.pokus.enums;

public enum GameStateEnum {
    WON,
    LOST,
    UNFINISHED,
    INVALID
}
