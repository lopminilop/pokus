package cz.pokus.pokus.enitities;

public class Move {
    private Long id;
    private Integer positionx;
    private Integer positiony;
    private Boolean revealed;
    private Boolean marked;
}