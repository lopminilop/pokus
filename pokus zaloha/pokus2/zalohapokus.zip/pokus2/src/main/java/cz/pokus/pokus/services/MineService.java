package cz.pokus.pokus.services;


import cz.pokus.pokus.MineSweeper.MineBoard;
import cz.pokus.pokus.exceptions.MarkException;
import cz.pokus.pokus.exceptions.MineExplodedException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MineService {
    private MineBoard board = new MineBoard();

    public List<List<Character>> drawBoard(){
        return board.drawBoard();
    }

    public List<List<Character>> getBoard(){
        board = new MineBoard();
        return board.drawBoard();
    }

    public List<List<Character>> markBoard(Integer x, Integer y){
        board.mark(x,y);
        return drawBoard();
    }


    public List<List<Character>> revealField(Integer x, Integer y) throws MarkException, MineExplodedException {
        board.reveal(x,y);
        return board.drawBoard();
    }
    public Integer minesLeft(){
        return board.minesleft;
    }

}
