package cz.pokus.pokus.enitities;

public class Mine {
    private Long id;
    private Integer positionx;
    private Integer positiony;
}
