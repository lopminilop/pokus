package cz.pokus.pokus.MineSweeper;

import cz.pokus.pokus.exceptions.MarkException;
import cz.pokus.pokus.exceptions.MineExplodedException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class MineBoard {
    private static final Integer HEIGHT = 10;
    private static final Integer WIDTH = 10;
    public static final Integer mineCount = HEIGHT*WIDTH/9;
    public boolean isGameOver = false;
    Integer leftToReveal = (HEIGHT ) * (WIDTH ) - mineCount;
    public  Integer minesleft=mineCount;



    public MineBoard() {
        mineFields = new ArrayList<>(HEIGHT);
        for (int y = 0; y < HEIGHT; y++) {
            mineFields.add(new ArrayList<>(WIDTH));
        }

        for (int y = 0; y < HEIGHT; y++) {
            for (int x = 0; x < WIDTH; x++) {
                mineFields.get(y).add(new MineField(false, false, false, 0));
            }
        }

        for (int i = 0; i < mineCount; i++) {
            Integer y = ThreadLocalRandom.current().nextInt(0, HEIGHT);
            Integer x = ThreadLocalRandom.current().nextInt(0, WIDTH);
            if (mineFields.get(x).get(y).getContainsMine()) {
                i--;
                continue;
            }
            else{
                addMine(x,y);

            }



        }


    }



    public void mark(Integer x, Integer y) {
        if(isGameOver) {
            return;
        }
        if(mineFields.get(x).get(y).revealed){
           return;
        }
        if (!mineFields.get(x).get(y).getMarked()) {
            mineFields.get(x).get(y).setMarked(true);
            minesleft--;
        }
        else{
            mineFields.get(x).get(y).setMarked(false);
            minesleft++;
        }

    }


    private void  addMine(Integer x, Integer y){
        mineFields.get(x).get(y).setContainsMine(true);
        //leftSide top to bottom
        Integer xCoord = x-1;
        for (int yIter = -1; yIter < 2; yIter++) {
           Integer yCoord = y+yIter;
            if(isInBound(xCoord,yCoord)){
                Integer oldMineCount=mineFields.get(xCoord).get(yCoord).getSurroundingMineCount();
                mineFields.get(xCoord).get(yCoord).setSurroundingMineCount(oldMineCount+1);
            }
        }
        //right Side top to bottom
        xCoord = x+1;
        for (int yIter = -1; yIter < 2; yIter++) {
            Integer yCoord = y + yIter;
            if(isInBound(xCoord,yCoord)) {
                Integer oldMineCount = mineFields.get(xCoord).get(yCoord).getSurroundingMineCount();
                mineFields.get(xCoord).get(yCoord).setSurroundingMineCount(oldMineCount + 1);
            }
        }
        //top
        xCoord=x;
        Integer yCoord=y-1;
        if(isInBound(xCoord,yCoord)){
            Integer oldMineCount = mineFields.get(xCoord).get(yCoord).getSurroundingMineCount();
            mineFields.get(xCoord).get(yCoord).setSurroundingMineCount(oldMineCount + 1);

        }
        //bottom
        yCoord=y+1;
        if(isInBound(xCoord,yCoord)){
            Integer oldMineCount = mineFields.get(xCoord).get(yCoord).getSurroundingMineCount();
            mineFields.get(xCoord).get(yCoord).setSurroundingMineCount(oldMineCount + 1);

        }
    }


    public void reveal(Integer x,Integer y) throws MineExplodedException, MarkException {
        if(isGameOver) {
            return;
        }
        if(mineFields.get(x).get(y).getRevealed()){
            return;
        }

        if(mineFields.get(x).get(y).getMarked()) {
            throw new MarkException("Nemuzete odhalit oznacene pole!");
        }

        mineFields.get(x).get(y).setRevealed(true);
        leftToReveal--;
        if(mineFields.get(x).get(y).getContainsMine()) {
            isGameOver=true;
            throw new MineExplodedException("Kopnul jste do miny!");
        }



        if(mineFields.get(x).get(y).getSurroundingMineCount().equals(0)) {
            Integer xCoord = x-1;
            for (int yIter = -1; yIter < 2; yIter++) {
                Integer yCoord = y+yIter;
                if(isInBound(xCoord,yCoord)){
                    reveal(xCoord,yCoord);

                    //mineFields.get(xCoord).get(yCoord).setRevealed(true);
                }
            }
            //right Side top to bottom
            xCoord = x+1;
            for (int yIter = -1; yIter < 2; yIter++) {
                Integer yCoord = y + yIter;
                if(isInBound(xCoord,yCoord)) {
                    reveal(xCoord,yCoord);
                }
            }
            //top
            xCoord=x;
            Integer yCoord=y-1;
            if(isInBound(xCoord,yCoord)){
                reveal(xCoord,yCoord);

            }
            //bottom
            yCoord=y+1;
            if(isInBound(xCoord,yCoord)){
                reveal(xCoord,yCoord);

            }

        }


    }

    private boolean isInBound(Integer x, Integer y) {
        return x.compareTo(0) >= 0 && y.compareTo(0) >= 0 && x.compareTo(MineBoard.WIDTH) < 0 && y.compareTo(MineBoard.HEIGHT) < 0;
    }

    public List<List<Character>> drawBoard() {
        //if(revealed)
        List<List<Character>> ret = new ArrayList<>(HEIGHT);
        for (int i = 0; i < HEIGHT; i++) {
            ret.add(new ArrayList<>(WIDTH));
        }
        if (leftToReveal > 0) {
            for (int y = 0; y < HEIGHT; y++) {
                for (int x = 0; x < WIDTH; x++) {
                    ret.get(y).add(mineFields.get(x).get(y).draw());
                }
            }
            return ret;
        }
        else{
            return Collections.emptyList();
        }
    }





    List<List<MineField>> mineFields;



}
