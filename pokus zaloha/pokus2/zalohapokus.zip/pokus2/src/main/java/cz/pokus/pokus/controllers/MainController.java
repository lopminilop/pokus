package cz.pokus.pokus.controllers;


import cz.pokus.pokus.MineSweeper.MineBoard;
import cz.pokus.pokus.ResponseDTO;
import cz.pokus.pokus.exceptions.MarkException;
import cz.pokus.pokus.exceptions.MineExplodedException;
import cz.pokus.pokus.services.MineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class MainController {

    @Autowired
    private MineService mineService;


    @RequestMapping(value = "getBoard", method = RequestMethod.GET)
    public ResponseDTO getBoard(){
        return new ResponseDTO("",mineService.getBoard(),mineService.minesLeft());
    }

    @RequestMapping(value="reveal", method = RequestMethod.PUT)
    public ResponseDTO revealField(@RequestParam Integer x, @RequestParam Integer y){
        System.out.println("Zavolano reveal s argumenty " + x +"," + y);
        try {
            List<List<Character>> boardState = mineService.revealField(x, y);
            if(boardState.isEmpty()) {
                return new ResponseDTO("VYHRAL SI!!!", boardState,mineService.minesLeft());
            }
            return new ResponseDTO("", boardState,mineService.minesLeft());

            //drawBoard
        } catch (MarkException e) {
            return new ResponseDTO(e.getMessage(), mineService.drawBoard(),mineService.minesLeft());
        } catch (MineExplodedException e) {
            return new ResponseDTO(e.getMessage(), mineService.drawBoard(),mineService.minesLeft());
        }
    }
    @RequestMapping(value="mark", method = RequestMethod.PUT)
    public ResponseDTO MarkBoard(@RequestParam Integer x, @RequestParam Integer y){
        return new ResponseDTO("", mineService.markBoard(x, y),mineService.minesLeft());
    }





}
