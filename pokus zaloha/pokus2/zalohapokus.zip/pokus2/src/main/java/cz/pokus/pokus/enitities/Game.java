package cz.pokus.pokus.enitities;

public class Game {
    private String name;
    private String player;
    private Long playerId;
    private Boolean revealed;
}
