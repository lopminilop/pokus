package cz.pokus.pokus.enitities;

import java.util.List;

public class Player {
    private Long id;
    private String name;
    private String email;
    private List<Game> Games;
}
